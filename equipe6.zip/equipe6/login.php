<?php
session_start();
require 'config.php';

if(!empty($_POST['usuario'])) {
	$usuario = addslashes($_POST['usuario']);
	$senha = md5($_POST['senha']);

	$sql = "SELECT id FROM usuarios WHERE usuario = '$usuario' AND senha = '$senha'";
	$sql = $pdo->query($sql);

	if($sql->rowCount() > 0) {
		$info = $sql->fetch();

	    $_SESSION['logado'] = $info['id'];
		header("Location: index.php");
		exit;
		 
		}else{
			?> 
			<div class="alert alert-danger" role="alert" align="center"><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
              Usuário ou Senha inválidos!
             </div>
             <?php 
                  
	}
}

?>

<!DOCTYPE html>
<html class="html">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<link rel="stylesheet" href="asset/css/estilo.css"  />
	<link rel="stylesheet" href="asset/bootstrap/bootstrap.min.css" />
	<script type="text/javascript" src="asset/js/jquery.min.js"></script>
	<script type="text/javascript" src="asset/js/bootstrap.min.js"></script>
	<meta charset="utf-8">
	<title>Tela de Login</title>
</head>

<body>
    <div class=login-page>

   <div class=row>
      <div>
       
         <div class="container">
    		<div class="row">
        		<div class=" col-md-12 text-center">
            		<img class="img-responsive" src="imagem/Banner.jpg" alt="Imagem"/>
        		</div>              
    		</div>
		</div>
		<br>
         <h1>Fast Logística<small><br> Sistema de Estoque</small></h1>
         <!--<img src="imagem/vovo1.jpg" img-responsive>!-->
         <form method="POST">
              	<div>
                	<input type=text size=36 name="usuario" placeholder=Usuário>
                </div>
               	<div>
                	<input type=password size=36  name="senha" placeholder=Senha>
                 </div>
            
            <button  type="submit" name="Entrar" type=submit class="btn btn-default">Entrar</button><br>
             <a href="admin.php">Acesso Restrito</a></p>
         </form>
      </div>
   </div>
</div>
</body>
<html>