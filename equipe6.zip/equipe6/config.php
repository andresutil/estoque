<?php

try {
	$pdo = new PDO("mysql:dbname=equipe6;host=localhost", "root", "asg1507");
} catch(PDOException $e) {
	echo "ERRO: ".$e->getMessage();
	exit;
}