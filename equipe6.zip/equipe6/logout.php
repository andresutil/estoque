<?
session_start();
session_unset();
session_destroy();

?>
<html><HEAD><TITLE>.:: ADMINISTRAÇÃO ::.</TITLE></HEAD>
<script>document.location = 'login.php'</script>
</head><body>

</body></html>
