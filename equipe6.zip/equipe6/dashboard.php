<?php
session_start();
require 'config.php';

if(empty($_SESSION['logado'])) {
	header("Location: login.php");
	exit;
}

$usario = '';
$senha = '';

$sql = "SELECT usuario, senha FROM usuarios WHERE id = '".addslashes($_SESSION['logado'])."'";
$sql = $pdo->query($sql);
if($sql->rowCount() > 0) {
	$info = $sql->fetch();
	$usuario = $info['usuario'];
	$Senha = $info['senha'];
}

?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <title>Painel Administrativo - Sistema de Estoque</title>

         <!-- Bootstrap CSS CDN -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <!-- Our Custom CSS -->
        <link rel="stylesheet" href="asset/css/estilo.css">
    </head>
    <body>



        <div class="wrapper">
            <!-- Sidebar Holder -->
            <nav id="sidebar">
                <div class="sidebar-header">
                    <h3>Dashboard</h3>
                    <strong>DS</strong>
                </div>

                <ul class="list-unstyled components">
                    <li class="active">
                        <a href="usuario.php" aria-expanded="false">
                            <i class="glyphicon glyphicon-user"></i>
                           Usuário
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="glyphicon glyphicon-briefcase"></i>
                            Estoque
                       </a>    
                    </li>                 
                    <li class="active">
                        <a href="index.php" aria-expanded="false">
                            <i class="glyphicon glyphicon-user"></i>
                           Home
                        </a>
                    </li> 
                </ul>

                
            </nav>
                 <!-- CONTAINER DO MEU!-->
                 <div class="container">                 
                        <div class="superior"><!-- MENU A DIREITA USUARIO!-->
                        <p><sttrong>Usuário Logado:</sttrong> <?php echo $usuario; ?></p>
                        <hr>
                 </div><!-- FIM MENU A DIREIRA USUAIRO !--> 
                <div class="row">
                    <div class="col-sm-4">
                        fwopefj
                    </div>
                <div>
                             
        </div><!-- FECHANDO WRAPPER !-->
       

        <!-- jQuery CDN -->
         <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
         <!-- Bootstrap Js CDN -->
         <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

         <script type="text/javascript">
             $(document).ready(function () {
                 $('#sidebarCollapse').on('click', function () {
                     $('#sidebar').toggleClass('active');
                 });
             });
         </script>
    </body>
</html>
