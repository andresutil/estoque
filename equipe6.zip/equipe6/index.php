<a href="dashboard.php">Acesso Restrito</a></p>

<?php

session_start();
require 'config.php';

if(empty($_SESSION['logado'])) {
	header("Location: login.php");
	exit;
}

$usario = '';
$senha = '';

$sql = "SELECT usuario, senha FROM usuarios WHERE id = '".addslashes($_SESSION['logado'])."'";
$sql = $pdo->query($sql);
if($sql->rowCount() > 0) {
	$info = $sql->fetch();
	$usuario = $info['usuario'];
	$Senha = $info['senha'];
}
?>
<div class=index>
    <div class="container">
    		<div class="row">
        		<div class=" col-md-10 text-center">
            		<img class="img-responsive" src="imagem/Banner.jpg" alt="Imagem"/>
        		</div>              
    		</div>
	</div>
<div align="center" class="index">

<h1>Bem vindo ao Sistema de Estoque da Fast Logisitca </h1>
<p><sttrong>Usuário Logado:</sttrong> <?php echo $usuario; ?> </p>
 
</body>
</html>