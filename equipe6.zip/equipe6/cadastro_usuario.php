<?php
session_start();
require 'config.php';

if(empty($_SESSION['logado'])) {
	header("Location: login.php");
	exit;
}

$usario = '';
$senha = '';

$sql = "SELECT usuario, senha FROM usuarios WHERE id = '".addslashes($_SESSION['logado'])."'";
$sql = $pdo->query($sql);
if($sql->rowCount() > 0) {
	$info = $sql->fetch();
	$usuario = $info['usuario'];
	$Senha = $info['senha'];
}

require 'classes/usuarios.class.php';
$u = new Usuarios(); 
if(isset($_POST['usuario']) && !empty($_POST['usuario'])) {
	$usuario = addslashes($_POST['usuario']);
    $senha = $_POST['senha'];
    	
    if(!empty($usuario) && !empty($senha)) {
        if($u->cadastrar($usuario, $senha)) {
            ?>
            <div class="alert alert-success">
                <strong>Parabéns!</strong> Cadastrado com sucesso. <a href="login.php" class="alert-link">Faça o login agora</a>
            </div>
            <?php
        } else {
            ?>
            <div class="alert alert-warning">
                Este usuário já existe! <a href="login.php" class="alert-link">Faça o login agora</a>
            </div>
            <?php
        }
    } else {
        ?>
        <div class="alert alert-warning">
            Preencha todos os campos!
        </div>
        <?php
    }
}
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <title>Cadastro de Usuário</title>

         <!-- Bootstrap CSS CDN -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <!-- Our Custom CSS -->
        <link rel="stylesheet" href="asset/css/estilo.css">
    </head>
    <body>
        <!-- class="wrapper"!-->
        <div class="wrapper">
            <!-- Sidebar Holder -->
            <nav id="sidebar">
                <div class="sidebar-header">
                    <h3>Dashboard</h3>
                    <strong>DS</strong>
                </div>

                <ul class="list-unstyled components">
                    <li class="active">
                        <a href="usuario.php" aria-expanded="false">
                            <i class="glyphicon glyphicon-user"></i>
                           Usuário
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="glyphicon glyphicon-briefcase"></i>
                            Estoque
                        </a>                 
                    </li> 
                    <li class="active">
                        <a href="index.php" aria-expanded="false">
                            <i class="glyphicon glyphicon-user"></i>
                           Home
                        </a>
                    </li>                                   
                </ul>
            </nav><!-- fim Sidebar Holder -->
            <!-- CONTAINER DO MEU!-->
                <div class="container">                 
                        <div class="superior"><!-- MENU A DIREITA USUARIO!-->
                        </a> <p><sttrong>Usuário Logado:</sttrong> <?php echo $usuario; ?></p>
                        <hr>
                        </div><!-- FIM MENU A DIREIRA USUAIRO !--> 
                        <!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <title>Cadastro de Usuário</title>

         <!-- Bootstrap CSS CDN -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <!-- Our Custom CSS -->
        <link rel="stylesheet" href="asset/css/estilo.css">
    </head>
    <body>
        <h2 class="novousuario">Cadastro de Usuário</h2>
        <form method="POST">
		<div class="form-group">
			<label for="nome">Usuário:</label>
			<input type="text" name="usuario" id="usuario" class="form-control" />
        </div>
		<div class="form-group">
			<label for="senha">Senha:</label>
			<input type="password" name="senha" id="senha" class="form-control" />
		</div>
		<input type="submit" value="Cadastrar" class="btn btn-default" />
	</form>
    </body>
</html>

            
