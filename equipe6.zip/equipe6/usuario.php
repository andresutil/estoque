<?php
session_start();
require 'config.php';

if(empty($_SESSION['logado'])) {
	header("Location: login.php");
	exit;
}

$usario = '';
$senha = '';

$sql = "SELECT usuario, senha FROM usuarios WHERE id = '".addslashes($_SESSION['logado'])."'";
$sql = $pdo->query($sql);
if($sql->rowCount() > 0) {
	$info = $sql->fetch();
	$usuario = $info['usuario'];
	$Senha = $info['senha'];
}

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <title>Usuário</title>

         <!-- Bootstrap CSS CDN -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <!-- Our Custom CSS -->
        <link rel="stylesheet" href="asset/css/estilo.css">
    </head>
    <body>
        <!-- class="wrapper"!-->
        <div class="wrapper">
            <!-- Sidebar Holder -->
            <nav id="sidebar">
                <div class="sidebar-header">
                    <h3>Dashboard</h3>
                    <strong>DS</strong>
                </div>

                <ul class="list-unstyled components">
                    <li class="active">
                        <a href="usuario.php" aria-expanded="false">
                            <i class="glyphicon glyphicon-user"></i>
                           Usuário
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="glyphicon glyphicon-briefcase"></i>
                            Estoque
                        </a>                 
                    </li>   
                    <li class="active">
                        <a href="index.php" aria-expanded="false">
                            <i class="glyphicon glyphicon-user"></i>
                           Home
                        </a>
                    </li>                                 
                </ul>
            </nav><!-- fim Sidebar Holder -->
            <!-- CONTAINER DO MEU!-->
                <div class="container">                 
                        <div class="superior"><!-- MENU A DIREITA USUARIO!-->
                         <p><sttrong>Usuário Logado:</sttrong> <?php echo $usuario; ?>
                    <a href="logout.php">Sair</a> </p>
                        <hr>
                        </div><!-- FIM MENU A DIREIRA USUAIRO !-->  
                        <!--Botão Adicionar Usuário !-->
                        <div class="row"> 
                            <div class="col-md-9">
                            <a href="cadastro_usuario.php"> <button type="button" class="btn btn-primary">Novo Usuário</button></a>
                            <table class="table">
                                <thead>
                                    <tr>
                                    <th scope="col">ID</th>
                                    <th scope=col">USUÁRIO</th>
                                    <th scope="col">SENHA</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
		  
          $sql = "SELECT * FROM usuarios order by id";
    
           $sql = $pdo->query($sql);
          if($sql->rowCount() >0){
            
                   foreach ($sql->fetchAll() as $usuario):
      ?>	
                    <!--  RETORNA MINHA TABELA COM OS DADOS PREENCHIDOS!-->
                       <tr>
                            <td><?php echo $usuario['id']; ?></td> 
                           <td><?php echo $usuario['usuario']; ?></td>
                            <td><?php echo $usuario['senha']; ?></td>
                            <td><a href="editar.php?id=<?php echo $usuario['id']; ?>" class="btn btn-default">Editar</a> </td>
                            <td> <a href="excluir.php?id=<?php echo $usuario['id']; ?>" class="btn btn-danger">Excluir</a>
                           </td>                 
      <?php
                    endforeach;
            }	
    
    
        ?>
                                                                  
                                </tbody>
                            </table>
                            </div> <!--Fim Do Botão Botão Adicionar Usuário !-->
                        </div>
                </div> <!-- FIM CONTAINER DO MENU!-->      
                
        </div><!-- Fim class="wrapper"!-->

        <!-- jQuery CDN -->
         <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
         <!-- Bootstrap Js CDN -->
         <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

         <script type="text/javascript">
             $(document).ready(function () {
                 $('#sidebarCollapse').on('click', function () {
                     $('#sidebar').toggleClass('active');
                 });
             });
         </script>
        
    </body>
</html>
