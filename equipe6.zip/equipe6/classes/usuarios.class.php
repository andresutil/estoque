<?php
class Usuarios {

	public function getTotalUsuarios() {
		global $pdo;

		$sql = $pdo->query("SELECT COUNT(*) as c FROM usuarios");
		$row = $sql->fetch();

		return $row['c'];
	}

	public function cadastrar($usuario, $senha) {
		global $pdo;
        $sql = $pdo->prepare("SELECT id FROM usuarios WHERE usuario = :senha");
        $sql->bindValue(":usuario", $usuario);
		$sql->bindValue(":senha", md5($senha));
		$sql->execute();

		if($sql->rowCount() == 0) {

			$sql = $pdo->prepare("INSERT INTO usuarios SET usuario = :usuario, senha = :senha");
			$sql->bindValue(":usuario", $usuario);
			$sql->bindValue(":senha", md5($senha));
			$sql->execute();

			return true;

		} else {
			return false;
		}

	}

	public function editUsuario($usuario, $senha, $id) {
		global $pdo;

		$sql = $pdo->prepare("UPDATE usuarios SET usuario = :usuario, senha = :senha WHERE id = :id");
		$sql->bindValue(":usuario", $usuario);
		$sql->bindValue(":senha", md5($senha));
		$sql->bindValue(":id", $id);
		$sql->execute();

	}

	public function login($email, $senha) {
		global $pdo;

		$sql = $pdo->prepare("SELECT id FROM usuarios WHERE email = :email AND senha = :senha");
		$sql->bindValue(":email", $email);
		$sql->bindValue(":senha", md5($senha));
		$sql->execute();

		if($sql->rowCount() > 0) { //verifica se tem algum usuario com essa senha/email
			$dado = $sql->fetch();
			$_SESSION['cLogin'] = $dado['id'];
			return true;
		} else {
			return false;
		}

	}


}
?>